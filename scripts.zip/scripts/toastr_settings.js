toastr.options = {
    "closeButton": true,
    "debug": false,
    "newestOnTop": false,
    "progressBar": true,
    "positionClass": "toast-bottom-right",  // 👈 pwesto
    "preventDuplicates": true,
    "onclick": null,
    "showDuration": 300,     // fade-in speed
    "hideDuration": 500,     // fade-out speed
    "timeOut": 4000,         // how long toast stays (ms)
    "extendedTimeOut": 1000, // after hover
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
  };
  