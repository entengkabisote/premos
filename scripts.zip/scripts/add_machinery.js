// Sample: scripts/add_machinery.js
$(document).ready(function() {
    loadMachinery();

    function loadMachinery() {
        $.get('get_machinery.php', function(data) {
            $('#machineryList').html(data);
        });
    }

    $('#addMachineryForm').submit(function(e) {
        e.preventDefault();
        var name = $('#machineryName').val();
        var type = $('#machineryType').val();
        $.post('add_machinery.php', { equipment_name: name, equipment_type: type }, function(res) {
            if (res.success) {
                toastr.success(res.message);
                loadMachinery();
                $('#addMachineryForm')[0].reset();
            } else {
                toastr.error(res.message);
            }
        }, 'json');
    });

    // Optional: delete event
    $(document).on('click', '.delete-machinery', function() {
        if (!confirm('Are you sure?')) return;
        var id = $(this).data('id');
        $.post('delete_machinery.php', { id: id }, function(res) {
            if (res.success) {
                toastr.success(res.message);
                loadMachinery();
            } else {
                toastr.error(res.message);
            }
        }, 'json');
    });
});
