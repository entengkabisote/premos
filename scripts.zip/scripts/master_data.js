// 📁 scripts/master_data.js

$(document).ready(function () {
    // ADD RANK
    $('#rankForm').submit(function (e) {
        e.preventDefault();
        let rank = $('#rankName').val().trim();

        if (rank === '') return;

        $.post('rank_add.php', { rank_name: rank }, function (response) {
            toastr.success('Rank added successfully');
            setTimeout(() => location.reload(), 1000);
        }).fail(() => toastr.error('Error adding rank'));
    });

    // DELETE RANK
    $('.delete-rank').click(function () {
        const id = $(this).data('id');
        if (confirm('Are you sure you want to delete this rank?')) {
            $.post('rank_delete.php', { id }, function () {
                toastr.success('Rank deleted');
                setTimeout(() => location.reload(), 800);
            }).fail(() => toastr.error('Delete failed'));
        }
    });

    // EDIT RANK
    $('.edit-rank').click(function () {
        const id = $(this).data('id');
        const current = $(this).data('name');
        const updated = prompt('Edit rank name:', current);
        if (updated && updated.trim() !== '' && updated !== current) {
            $.post('rank_edit.php', { id, rank_name: updated }, function () {
                toastr.success('Rank updated');
                setTimeout(() => location.reload(), 800);
            }).fail(() => toastr.error('Update failed'));
        }
    });

    // ADD INTERVAL
    $('#intervalForm').submit(function (e) {
        e.preventDefault();
        let name = $('#intervalName').val().trim();
        let days = $('#intervalDays').val().trim();

        if (name === '' || days === '') return;

        $.post('interval_add.php', { name: name, days: days }, function () {
            toastr.success('Interval added');
            setTimeout(() => location.reload(), 1000);
        }).fail(() => toastr.error('Add interval failed'));
    });

    // DELETE INTERVAL
    $('.delete-interval').click(function () {
        const id = $(this).data('id');
        if (confirm('Delete this interval?')) {
            $.post('interval_delete.php', { id }, function () {
                toastr.success('Interval deleted');
                setTimeout(() => location.reload(), 800);
            }).fail(() => toastr.error('Delete failed'));
        }
    });

    // EDIT INTERVAL
    $('.edit-interval').click(function () {
        const id = $(this).data('id');
        const name = $(this).data('name');
        const days = $(this).data('days');
        const newName = prompt('Edit interval name:', name);
        const newDays = prompt('Edit number of days:', days);

        if (newName && newDays && (newName !== name || newDays !== days)) {
            $.post('interval_edit.php', { id, name: newName, days: newDays }, function () {
                toastr.success('Interval updated');
                setTimeout(() => location.reload(), 800);
            }).fail(() => toastr.error('Update failed'));
        }
    });

        // ADD CRITICALITY
    $('#criticalityForm').submit(function (e) {
        e.preventDefault();
        let level = $('#criticalityLevel').val().trim();
        if (level === '') return;

        $.post('criticality_add.php', { level }, function () {
            toastr.success('Criticality level added');
            setTimeout(() => location.reload(), 1000);
        }).fail(() => toastr.error('Add failed'));
    });

    // DELETE CRITICALITY
    $('.delete-criticality').click(function () {
        const id = $(this).data('id');
        if (confirm('Delete this criticality level?')) {
            $.post('criticality_delete.php', { id }, function () {
                toastr.success('Deleted successfully');
                setTimeout(() => location.reload(), 800);
            }).fail(() => toastr.error('Delete failed'));
        }
    });

    // EDIT CRITICALITY
    $('.edit-criticality').click(function () {
        const id = $(this).data('id');
        const current = $(this).data('level');
        const updated = prompt('Edit level:', current);
        if (updated && updated.trim() !== '' && updated !== current) {
            $.post('criticality_edit.php', { id, level: updated }, function () {
                toastr.success('Updated successfully');
                setTimeout(() => location.reload(), 800);
            }).fail(() => toastr.error('Update failed'));
        }
    });

    // ADD EQUIPMENT TYPE
    $('#equipmentTypeForm').submit(function (e) {
        e.preventDefault();
        let type = $('#equipmentType').val().trim();
        if (type === '') return;

        $.post('equipment_type_add.php', { type }, function () {
            toastr.success('Equipment type added');
            setTimeout(() => location.reload(), 1000);
        }).fail(() => toastr.error('Add failed'));
    });

    // DELETE
    $('.delete-equipment-type').click(function () {
        const id = $(this).data('id');
        if (confirm('Delete this equipment type?')) {
            $.post('equipment_type_delete.php', { id }, function () {
                toastr.success('Deleted successfully');
                setTimeout(() => location.reload(), 800);
            }).fail(() => toastr.error('Delete failed'));
        }
    });

    // EDIT
    $('.edit-equipment-type').click(function () {
        const id = $(this).data('id');
        const current = $(this).data('type');
        const updated = prompt('Edit equipment type:', current);
        if (updated && updated.trim() !== '' && updated !== current) {
            $.post('equipment_type_edit.php', { id, type: updated }, function () {
                toastr.success('Updated successfully');
                setTimeout(() => location.reload(), 800);
            }).fail(() => toastr.error('Update failed'));
        }
    });

    // ADD ANCILLARY TYPE
    $('#ancillaryTypeForm').submit(function (e) {
        e.preventDefault();
        let type = $('#ancillaryType').val().trim();
        if (type === '') return;

        $.post('ancillary_type_add.php', { type }, function () {
            toastr.success('Ancillary type added');
            setTimeout(() => location.reload(), 1000);
        }).fail(() => toastr.error('Add failed'));
    });

    // DELETE
    $('.delete-ancillary-type').click(function () {
        const id = $(this).data('id');
        if (confirm('Delete this ancillary type?')) {
            $.post('ancillary_type_delete.php', { id }, function () {
                toastr.success('Deleted successfully');
                setTimeout(() => location.reload(), 800);
            }).fail(() => toastr.error('Delete failed'));
        }
    });

    // EDIT
    $('.edit-ancillary-type').click(function () {
        const id = $(this).data('id');
        const current = $(this).data('type');
        const updated = prompt('Edit ancillary type:', current);
        if (updated && updated.trim() !== '' && updated !== current) {
            $.post('ancillary_type_edit.php', { id, type: updated }, function () {
                toastr.success('Updated successfully');
                setTimeout(() => location.reload(), 800);
            }).fail(() => toastr.error('Update failed'));
        }
    });

    // ADD MACHINERY CATEGORY
    $('#machineryCategoryForm').submit(function (e) {
        e.preventDefault();
        let category = $('#machineryCategory').val().trim();
        if (category === '') return;

        $.post('machinery_category_add.php', { category_name: category }, function () {
            toastr.success('Machinery category added');
            setTimeout(() => location.reload(), 1000);
        }).fail(() => toastr.error('Add failed'));
    });

    // DELETE
    $('.delete-machinery-category').click(function () {
        const id = $(this).data('id');
        if (confirm('Delete this machinery category?')) {
            $.post('machinery_category_delete.php', { id }, function () {
                toastr.success('Deleted successfully');
                setTimeout(() => location.reload(), 800);
            }).fail(() => toastr.error('Delete failed'));
        }
    });

    // EDIT
    $('.edit-machinery-category').click(function () {
        const id = $(this).data('id');
        const current = $(this).data('name');
        const updated = prompt('Edit category name:', current);
        if (updated && updated.trim() !== '' && updated !== current) {
            $.post('machinery_category_edit.php', { id, category_name: updated }, function () {
                toastr.success('Updated successfully');
                setTimeout(() => location.reload(), 800);
            }).fail(() => toastr.error('Update failed'));
        }
    });

});

