// $(function() {
//     toastr.info("Toastr loaded and working!");
// });


$("#addEquipmentForm").submit(function(e) {
    e.preventDefault();
    
    // Validation check for equipmentCategory
    var equipmentCategory = $('#equipmentCategory').val();
    if (equipmentCategory === "") {
        // alert("Please select a category.");
        toastr.warning("Please select a category.");
        return; // Stop the form submission if no category is selected
    }

    // Proceed with AJAX call if validation passes
    $.ajax({
    url: "add_equipment.php",
    type: "POST",
    data: {
        equipmentName: $('#equipmentName').val(),
        equipmentCategory: equipmentCategory // Use the validated category value
    },
    success: function(data) {
        var parsedData = JSON.parse(data);
        if (parsedData.status === 'success') {
            toastr.success("Equipment added successfully!");
            var catName = categoryMap[equipmentCategory];
            var newRow = "<tr><td>" + $('#equipmentName').val() + "</td><td>" + catName + "</td><td>Action</td></tr>";
            $("#equipmentList").append(newRow);
            loadExistingData();  // ← Nandito pa rin, walang tanggal
        } else if (parsedData.status === 'duplicate') {
            toastr.error("Duplicate equipment name.");
        } else {
            toastr.error("Failed to add equipment.");
        }
    },
    complete: function() {
        // Clear the input fields
        $('#equipmentName').val('');
        $('#equipmentCategory').val('');
    }
    });
});


function loadExistingData() {
    $.ajax({
        url: "get_equipment.php",
        type: "GET",
        success: function(data) {
            var parsedData = JSON.parse(data);

            // Modified sort to handle NULL or undefined category values
            parsedData.sort((a, b) => {
                if (!a.category || !b.category) {
                    return 0; // Do not change order if one of the categories is null or undefined
                }
                return a.category.localeCompare(b.category);
            });

            // Clear existing rows
            $("#equipmentList").empty();

            // Initialize counter for numbering
            let counter = 1;

            console.log(parsedData);

            parsedData.forEach(function(row) {
                console.log('Equipment ID:', row.equipment_id); // Debug log

                var newRow = `<tr data-equipment-id="${row.equipment_id}">
                    <td>${counter}. ${row.equipment_name}</td>
                    <td>${row.category}</td>
                    <td>
                    <button class="btn btn-sm btn-outline-primary edit-btn">✏</button>
                    <button class="btn btn-sm btn-outline-danger delete-btn">🗑</button>
                    </td>
                </tr>`;

                $("#equipmentList").append(newRow);
                counter++;
            });
        }
    });
}



    var categoryMap = {};

    $(document).ready(function() {
        $('#equipmentCategory option').each(function() {
            var id = $(this).val();
            var name = $(this).data('type-name');
            categoryMap[id] = name;
        });

        loadExistingData();
    });


    // ******************************************************************** //
    //                Add event listeners for Edit buttons
    // ******************************************************************** //
    
    $(document).on('click', '.edit-btn', function() {
        var equipmentId = $(this).closest('tr').data('equipment-id');
        window.location.href = `edit_equipment.php?id=${equipmentId}`;
    });

    // ******************************************************************** //
    //              Add event listeners for Delete buttons
    // ******************************************************************** //

    $(document).on('click', '.delete-btn', function() {
        var equipmentId = $(this).closest('tr').data('equipment-id');

        if (confirm('Are you sure you want to delete this equipment?')) {
            $.ajax({
                url: 'delete_equipment.php',
                type: 'POST',
                data: { id: equipmentId },
                success: function(data) {
                    var response = JSON.parse(data);

                    if (response.status === 'success') {
                        // alert('Equipment deleted successfully.');
                        toastr.success('Equipment deleted successfully.');
                        // Optional: Reload the table or remove the row from the DOM
                        loadExistingData();
                    } else {
                        // alert(response.message);
                        toastr.error(response.message);
                    }
                },
                error: function(err) {
                    console.error("Error:", err);
                    // alert('An error occurred. Please try again.');
                    toastr.error('An error occurred. Please try again.');
                }
            });
        }
    });
