function toggleMenu() {
    const menus = document.querySelectorAll(".dropdown-menu");
    menus.forEach(menu => {
        menu.style.display = (menu.style.display === "block") ? "none" : "block";
    });
}

document.addEventListener("click", function(event) {
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const avatar = menu.previousElementSibling;
        if (!menu.contains(event.target) && !avatar.contains(event.target)) {
            menu.style.display = "none";
        }
    });
});

function resetAvatarPosition() {
    localStorage.removeItem("avatarX");
    localStorage.removeItem("avatarY");

    const avatar = document.getElementById("draggableAvatar");
    if (avatar) {
        avatar.style.left = "20px";
        avatar.style.top = "50%";
        avatar.style.transform = "translateY(-50%)";
    }
}


window.addEventListener("DOMContentLoaded", function () {
    const dragItem = document.getElementById("draggableAvatar");
    if (!dragItem) return;

    // Load saved position
    const savedX = localStorage.getItem("avatarX");
    const savedY = localStorage.getItem("avatarY");
    if (savedX && savedY) {
        dragItem.style.left = `${savedX}px`;
        dragItem.style.top = `${savedY}px`;
        dragItem.style.right = "auto";
        dragItem.style.transform = "none";
    }

    let isDragging = false;
    let offsetX, offsetY;

    dragItem.addEventListener("mousedown", function (e) {
        isDragging = true;
        offsetX = e.clientX - dragItem.getBoundingClientRect().left;
        offsetY = e.clientY - dragItem.getBoundingClientRect().top;
        dragItem.style.transition = "all 0.2s ease"; // when not dragging

        // dragItem.style.transition = "left 0.05s linear, top 0.05s linear"; // short smooth drag

        // dragItem.style.transition = "none"; // remove smooth for drag
    });

    document.addEventListener("mousemove", function (e) {
        if (!isDragging) return;

        // Limit to screen bounds
        const newX = Math.min(window.innerWidth - dragItem.offsetWidth, Math.max(0, e.clientX - offsetX));
        const newY = Math.min(window.innerHeight - dragItem.offsetHeight, Math.max(0, e.clientY - offsetY));

        dragItem.style.left = `${newX}px`;
        dragItem.style.top = `${newY}px`;
        dragItem.style.right = "auto";
        dragItem.style.bottom = "auto";
        dragItem.style.transform = "none";
    });

    document.addEventListener("mouseup", function () {
        if (!isDragging) return;
        isDragging = false;

        // Save to localStorage
        const finalX = parseInt(dragItem.style.left, 10);
        const finalY = parseInt(dragItem.style.top, 10);
        localStorage.setItem("avatarX", finalX);
        localStorage.setItem("avatarY", finalY);

        dragItem.style.transition = "all 0.2s ease"; // smooth when not dragging
    });
});
