$(document).ready(function () {

    // Add Row (Bootstrap only, no double row bug)
    $("#addRow").click(function () {
        var $originalRow = $(".inspectionRow:first");
        var $newRow = $originalRow.clone();

        // Clean input/select
        $newRow.find("input").val("");
        $newRow.find("select").val("");
        $newRow.find(".removeRow").removeClass("d-none").show();

        $("#inspectionMetaContainer").append($newRow);
    });

    // Remove Row
    $(document).on("click", ".removeRow", function () {
        if ($(".inspectionRow").length > 1) {
            $(this).closest(".inspectionRow").remove();
        }
    });

    $("#editEquipmentForm").submit(function(e) {
        e.preventDefault();

        var equipmentId = $("#equipmentId").val();
        var equipmentName = $("#equipmentName").val();
        var category = $("#category").val();

        $.ajax({
            url: "update_equipment_and_meta.php",
            type: "POST",
            data: {
                equipment_id: equipmentId,
                equipment_name: equipmentName,
                category: category
            },
            success: function(response) {
                toastr.success("Successfully updated!");
            },
            error: function() {
                toastr.error("Update failed.");
            }
        });
    });

     // Save Equipment Form
    // $("#editEquipmentForm").submit(function(e) {
    //     e.preventDefault();

    //     var equipmentId = $("#equipmentId").val();
    //     var equipmentName = $("#equipmentName").val();
    //     var category = $("#category").val();

    //     var inspectionMeta = [];
    //     // Pwede mong dagdagan ito para i-loop yung inspection rows kung kailangan mo rin i-save lahat ng inspections sa isang submit

    //     $.ajax({
    //         url: "update_equipment_and_meta.php",
    //         type: "POST",
    //         data: {
    //             equipment_id: equipmentId,
    //             equipment_name: equipmentName,
    //             category: category,
    //             inspection_meta: JSON.stringify(inspectionMeta) // kahit empty pwede
    //         },
    //         success: function(response) {
    //             alert("Successfully updated!");
    //             // Optionally: refresh page or table if needed
    //         },
    //         error: function() {
    //             alert("Update failed.");
    //         }
    //     });
    // });


    // Save Inspect
    $("#saveInspection").click(function () {
        let inspectionData = [];
        let uniqueTypes = new Set();
        let hasDuplicate = false;

        $(".inspectionRow").each(function () {
            let type = $.trim($(this).find("input[name='inspection_type[]']").val());
            let interval = $(this).find("select[name='inspection_interval[]']").val();
            let person = $(this).find("input[name='person_in_charge[]']").val();
            let criticality = $(this).find("input[name='criticality[]']").val();

            if (type !== "") {
                inspectionData.push({ type: type, interval, person, criticality });
            }

            if (uniqueTypes.has(type)) {
                // alert("Duplicate type of inspection: " + type);
                toastr.error("Duplicate type of inspection: " + type);
                hasDuplicate = true;
                return false;
            } else {
                uniqueTypes.add(type);
            }
        });

        let equipmentId = $("#equipmentId").val();

        if (!equipmentId || isNaN(equipmentId)) {
            alert("Invalid equipment ID.");
            return;
        }

        if (inspectionData.length === 0) {
            alert("No valid inspection data provided.");
            return;
        }
        if (!hasDuplicate) {
            $.ajax({
                url: "save_inspection_meta.php",
                type: "POST",
                data: {
                    equipmentId: equipmentId,
                    inspection_data: JSON.stringify(inspectionData)
                },
                success: function (response) {
                    const parsedResponse = JSON.parse(response);
                    if (parsedResponse.status === 'success') {
                        // alert("Inspection data successfully saved!");
                        toastr.success("Inspection data successfully saved!");
                        displayInspectionTypes(parsedResponse.data);
                    } else if (parsedResponse.status === 'duplicate') {
                        alert("Duplicate inspection types detected.");
                    } else {
                        alert("Failed to save inspection data.");
                    }
                    // Clear the input fields
                    $(".inspectionRow input[type='text']").val('');
                    $(".inspectionRow select").val('');
                },
                error: function (xhr, status, error) {
                    // alert("Failed to save inspection data.");
                    toastr.error("Failed to save inspection data.");
                }
            });
        }
    });

    // For Edit/Delete in the inspection table (use Bootstrap modal as needed)
    $(document).on('click', '.btn-delete', function () {
        var row = $(this).closest('tr');
        var metaId = row.data('meta-id');
        if (confirm("Are you sure you want to delete this record?")) {
            $.ajax({
                url: "delete_meta.php",
                type: "POST",
                data: { meta_id: metaId },
                dataType: "json",
                success: function (response) {
                    if (response.status === "success") {
                        row.remove();
                        toastr.success(response.message);
                    } else {
                        toastr.error("Error: " + response.message);
                    }

                    // if (response.status === "success") {
                    //     row.remove();
                    //     if (typeof showToast === "function") showToast(response.message, "bg-success");
                    // } else {
                    //     alert("Error: " + response.message);
                    // }
                },
                error: function () {
                    toastr.error("Something went wrong with the request.");
                }

                // error: function () {
                //     alert("Something went wrong with the request.");
                // }
            });
        }
    });

    // Edit functionality (pwede mo ilagay sa modal logic, depende sa gusto mo)
    // Pwedeng gamitin ang Bootstrap Modal kung kailangan

});

// For displaying returned inspection types in table after save
function displayInspectionTypes(inspectionTypes) {
    const tableBody = $('#inspectionMetaContainer2 table tbody');
    tableBody.empty();
    inspectionTypes.forEach(type => {
        const row = `
            <tr data-meta-id="${type.meta_id}">
                <td>${type.inspection_type}</td>
                <td>${type.inspection_interval}</td>
                <td>${type.person_in_charge}</td>
                <td>${type.criticality}</td>
                <td>
                    <a href="edit_inspection_type.php?meta_id=${type.meta_id}&equipment_id=${$('#equipmentId').val()}" class="btn btn-primary btn-sm me-1">Edit</a>
                    <button type="button" class="btn btn-danger btn-sm btn-delete">Delete</button>
                </td>
            </tr>
        `;
        tableBody.append(row);
    });
}
