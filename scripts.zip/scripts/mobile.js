window.addEventListener("DOMContentLoaded", function () {
    const dragItem = document.getElementById("draggableAvatar");
    if (!dragItem) return;

    // Load saved position
    const savedX = localStorage.getItem("avatarX");
    const savedY = localStorage.getItem("avatarY");
    if (savedX && savedY) {
        dragItem.style.left = `${savedX}px`;
        dragItem.style.top = `${savedY}px`;
        dragItem.style.right = "auto";
        dragItem.style.transform = "none";
    }

    let isDragging = false;
    let offsetX, offsetY;

    // Desktop Events
    dragItem.addEventListener("mousedown", function (e) {
        isDragging = true;
        offsetX = e.clientX - dragItem.getBoundingClientRect().left;
        offsetY = e.clientY - dragItem.getBoundingClientRect().top;
        dragItem.style.transition = "all 0.2s ease";
    });

    document.addEventListener("mousemove", function (e) {
        if (!isDragging) return;
        const newX = Math.min(window.innerWidth - dragItem.offsetWidth, Math.max(0, e.clientX - offsetX));
        const newY = Math.min(window.innerHeight - dragItem.offsetHeight, Math.max(0, e.clientY - offsetY));
        dragItem.style.left = `${newX}px`;
        dragItem.style.top = `${newY}px`;
        dragItem.style.transform = "none";
    });

    document.addEventListener("mouseup", function () {
        if (!isDragging) return;
        isDragging = false;
        const finalX = parseInt(dragItem.style.left, 10);
        const finalY = parseInt(dragItem.style.top, 10);
        localStorage.setItem("avatarX", finalX);
        localStorage.setItem("avatarY", finalY);
        dragItem.style.transition = "all 0.2s ease";
    });

    // Mobile Events
    dragItem.addEventListener("touchstart", function (e) {
        isDragging = true;
        const touch = e.touches[0];
        offsetX = touch.clientX - dragItem.getBoundingClientRect().left;
        offsetY = touch.clientY - dragItem.getBoundingClientRect().top;
        dragItem.style.transition = "all 0.2s ease";
    }, { passive: true });

    document.addEventListener("touchmove", function (e) {
        if (!isDragging) return;
        const touch = e.touches[0];
        const newX = Math.min(window.innerWidth - dragItem.offsetWidth, Math.max(0, touch.clientX - offsetX));
        const newY = Math.min(window.innerHeight - dragItem.offsetHeight, Math.max(0, touch.clientY - offsetY));
        dragItem.style.left = `${newX}px`;
        dragItem.style.top = `${newY}px`;
        dragItem.style.transform = "none";
    }, { passive: true });

    document.addEventListener("touchend", function () {
        if (!isDragging) return;
        isDragging = false;
        const finalX = parseInt(dragItem.style.left, 10);
        const finalY = parseInt(dragItem.style.top, 10);
        localStorage.setItem("avatarX", finalX);
        localStorage.setItem("avatarY", finalY);
        dragItem.style.transition = "all 0.2s ease";
    });
});
