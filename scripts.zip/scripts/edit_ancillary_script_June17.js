function fetchInspectionTypes(equipmentId) {
    $.ajax({
        url: 'get_ancillary_inspection_types.php',
        method: 'POST',
        data: { equipmentId: equipmentId },
        success: function(response) {
            const data = JSON.parse(response);
            if (data.status === 'success') {
                displayInspectionTypes(data.data);
            } else {
                // alert("Error fetching inspection types: " + data.message);
                showToast("Error fetching inspection types: " + data.message, "bg-danger");            
            }
        }
    });
}


$(document).ready(function() {
    attachEventListeners();

    $("#addRow").click(function() {
        // Only clone the first .inspectionRow (template), not all rows
        var originalRow = $(".inspectionRow").first();
        var newRow = originalRow.clone();

        // Clean up the cloned row
        newRow.find("input").val("");
        newRow.find("select").val('');
        newRow.find(".removeRow").removeClass('d-none').show();

        // Append after the last .inspectionRow
        $("#inspectionMetaContainer").append(newRow);
    });

    $(document).on("click", ".removeRow", function() {
        // Only remove if more than one row left
        if ($(".inspectionRow").length > 1) {
            $(this).closest(".inspectionRow").remove();
        }
    });

    $("#saveInspection").click(function() {
        let inspectionData = [];
        let uniqueTypes = new Set();
        let hasDuplicate = false;

        $(".inspectionRow").each(function() {
            let type = $.trim($(this).find("input[name='inspection_type[]']").val());
            let interval = $(this).find("select[name='inspection_interval[]']").val();
            let person = $(this).find("input[name='person_in_charge[]']").val();
            let criticality = $(this).find("input[name='criticality[]']").val();

            if (type !== "") {
                inspectionData.push({type: type, interval, person, criticality});
            }

            if (uniqueTypes.has(type)) {
                // alert("Duplicate type of inspection: " + type);
                showToast("Duplicate type of inspection: " + type, "bg-danger");
                hasDuplicate = true;
                return false;
            } else {
                uniqueTypes.add(type);
            }
        });

        let equipmentId = $("#equipmentId").val();
        if (!equipmentId || isNaN(equipmentId)) {
            // alert("Invalid equipment ID.");
            showToast("Invalid equipment ID.", "bg-danger");
            return;
        }
        if (inspectionData.length === 0) {
            alert("No valid inspection data provided.");
            return;
        }

        if (!hasDuplicate) {
            $.ajax({
                url: "save_ancillary_inspection_meta.php",
                type: "POST",
                data: {
                    equipmentId: equipmentId,
                    inspection_data: JSON.stringify(inspectionData)
                },
                success: function(response) {
                    const parsedResponse = JSON.parse(response);
                    if (parsedResponse.status === 'success') {
                        // alert("Inspection data successfully saved!");
                        showToast("Inspection data successfully saved!", "bg-success");

                        displayInspectionTypes(parsedResponse.data);
                    } else if (parsedResponse.status === 'duplicate') {
                        alert("Duplicate inspection types detected.");
                    } else {
                        alert("Failed to save inspection data.");
                    }
                    $(".inspectionRow input[type='text']").val('');
                    $(".inspectionRow select").val('');
                },
                error: function(xhr, status, error) {
                    alert("Failed to save inspection data.");
                }
            });
        }
    });

    $("#editEquipmentForm").submit(function(e) {
            e.preventDefault();
        
            var equipmentId = $("#equipmentId").val();
            var equipmentName = $("#equipmentName").val();
            var category = $("#category").val();  // get  category value
        
            var inspectionMeta = [];
            $(".inspectionMeta").each(function() {
                var type = $(this).find(".inspectionType").val();
                // Add other fields like inspection_interval, person_in_charge, etc.
                
                inspectionMeta.push({type: type});
            });
        
            console.log("equipmentId before sending AJAX request: " + equipmentId);
        
            $.ajax({
                url: "update_ancillary_and_meta.php",
                type: "POST",
                data: {
                    equipment_id: equipmentId,
                    equipment_name: equipmentName,
                    category: category, // Idagdag sa AJAX data
                    inspection_meta: JSON.stringify(inspectionMeta)
                },
                success: function(response) {
                    alert("Successfully updated!");
                },
                error: function() {
                    alert("Update failed.");
                }
            });
        });

    // $("#editEquipmentForm").submit(function(e) {
    //     e.preventDefault();

    //     var equipmentId = $("#equipmentId").val();
    //     var equipmentName = $("#equipmentName").val();
    //     var category = $("#category").val();

    //     $.ajax({
    //         url: "update_ancillary_and_meta.php", // ito dapat ang PHP handler mo
    //         type: "POST",
    //         data: {
    //             equipment_id: equipmentId,
    //             equipment_name: equipmentName,
    //             category: category
    //         },
    //         success: function(response) {
    //             alert("Successfully updated!");
    //             // Optional: pwede mo i-reload or show toast dito
    //         },
    //         error: function() {
    //             alert("Update failed.");
    //         }
    //     });
    // });

    const equipmentId = $("#equipmentId").val();
    fetchInspectionTypes(equipmentId);

});

// Table row display
function displayInspectionTypes(inspectionTypes) {
    const tableBody = $('#inspectionMetaContainer2 table tbody');
    tableBody.empty();
    inspectionTypes.forEach(type => {
        const row = `
            <tr data-meta-id="${type.meta_id}">
                <td>${type.inspection_type}</td>
                <td>${type.inspection_interval}</td>
                <td>${type.person_in_charge}</td>
                <td>${type.criticality}</td>
                <td>
                    <a href="edit_ancillary_inspection_type.php?meta_id=${type.meta_id}&equipment_id=${type.equipment_id}" class="btn btn-primary btn-sm me-1">Edit</a>
                    <button type="button" class="btn btn-danger btn-sm btn-delete">Delete</button>
                </td>
            </tr>
        `;
        tableBody.append(row);
    });
    attachEventListeners();
}

// Attach edit/delete buttons (Edit = just link, Delete = AJAX)
function attachEventListeners() {
    $(document).off('click', '.btn-delete');
    $(document).on('click', '.btn-delete', function() {
        var row = $(this).closest('tr');
        var metaId = row.data('meta-id');
        if (confirm("Are you sure you want to delete this record?")) {
            $.ajax({
                url: "delete_ancillary_meta.php",
                type: "POST",
                data: { meta_id: metaId },
                dataType: "json",
                success: function(response) {
                    if(response.status === "success") {
                        alert(response.message);
                        row.remove();
                    } else {
                        alert("Error: " + response.message);
                    }
                },
                error: function() {
                    alert("Something went wrong with the request.");
                }
            });
        }
    });
}
